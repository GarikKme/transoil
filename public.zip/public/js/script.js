/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/js/script.js":
/*!**************************!*\
  !*** ./src/js/script.js ***!
  \**************************/
/***/ (() => {

function initScript() {
  var mediaQuery = window.matchMedia("(max-width: 992px)");
  var bars = document.querySelector(".bars"),
    navOverlay = document.querySelector(".nav-overlay"),
    menu = document.querySelector(".header-nav");
  function resizeNav() {
    // Set the circle radius to the length of the window diagonal,
    // this way we're only making the circle as big as it needs to be.
    var radius = Math.sqrt(Math.pow(window.innerHeight, 2) + Math.pow(window.innerWidth, 2));
    var diameter = radius * 2;
    navOverlay.style.width = diameter + "px";
    navOverlay.style.height = diameter + "px";
    navOverlay.style.marginTop = -radius + "px";
    navOverlay.style.marginLeft = -radius + "px";
  }
  if (mediaQuery.matches) {
    // Set the nav height to fill the window
    document.querySelector(".header-nav").style.height = window.innerHeight + "px";
  } else {
    document.querySelector(".header-nav").style.height = "unset";
  }

  // Set up click and window resize callbacks, then init the nav.
  bars.addEventListener("click", function () {
    this.classList.toggle("open");
    navOverlay.classList.toggle("open");
    menu.classList.toggle("open");
    document.querySelector("body").classList.toggle("openMenu");
    document.querySelectorAll("li.header__menu-item").forEach(function (item) {
      return item.classList.toggle("show");
    });
    var wrapFadeUp = document.querySelector(".fade-up.header__wrapper");
    wrapFadeUp.classList.toggle("show");
  });

  //fade-up header__wrapper

  //window.resize(resizeNav());

  resizeNav();
}
window.onload = initScript;

//tabs on services screen

var tabs = document.querySelectorAll(".tab-btn");
var content = document.querySelectorAll(".content");
function changeClass(el) {
  el.classList.toggle("active");
}
tabs.forEach(function (item) {
  item.addEventListener("click", function (e) {
    var currentTab = item.dataset.btn;
    changeClass(item);
    for (var i = 0; i < content.length; i++) {
      content[i].classList.remove("active");
      if (content[i].dataset.content === currentTab) {
        content[i].classList.add("active");
      }
    }
  });
});

// services mobile accordion

//accord creation function on services

function accordCreate(accord) {
  accord.forEach(function (item) {
    item.addEventListener("click", function () {
      this.classList.toggle("active");
      this.nextElementSibling.classList.toggle("active");
    });
  });
}

//faq accordion function
var accordTitle = document.querySelectorAll(".accord__title");
if (accordTitle) {
  accordCreate(accordTitle);
}
var isInView = function isInView(elem) {
  var bottom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 30;
  // Get the top and bottom of the viewport.
  var docViewTop = window.pageYOffset;
  var docViewBottom = docViewTop + window.innerHeight;

  // Get the top and bottom of the element.
  var elemTop = elem.offsetTop;
  var elemBottom = elemTop + bottom;

  // Return true if the element is within the viewport.
  return elemBottom <= docViewBottom && elemTop >= docViewTop;
};
var animations = {
  fadeUp: [{
    isElementsCreated: false,
    isElementsFired: false
  }, {
    isElementsCreated: false,
    isElementsFired: false
  }, {
    isElementsCreated: false,
    isElementsFired: false
  }, {
    isElementsCreated: false,
    isElementsFired: false
  }]
};
var initAnimations = function initAnimations() {
  var initFadeUp = function initFadeUp() {
    var fadeUp = document.querySelectorAll(".fade-up");
    fadeUp.forEach(function (element, index) {
      if (!animations.fadeUp[index].isElementsCreated) {
        var container = element.dataset.container;
        var child = document.createElement(container || "span");
        child.classList.add("fade-up-child");
        child.innerHTML = element.innerHTML;
        element.innerHTML = "";
        element.appendChild(child);
        animations.fadeUp[index].isElementsCreated = true;
      }
      if (isInView(element) && !animations.fadeUp[index].isElementsFired) {
        element.querySelector(".fade-up-child").classList.add("visible");
        element.classList.add("shown");
        animations.fadeUp[index].isElementsFired = true;
      }
    });
  };
  var initAbout = function initAbout() {
    var about = document.querySelector("#about");
    var isVisible = isInView(about, 300);
    if (isVisible) {
      var number = about.querySelector(".zoom-appear");
      var slidesIn = about.querySelectorAll(".slideInRight");
      var zoomDown = about.querySelector(".zoomDown");
      number.classList.add("visible");
      zoomDown.classList.add("visible");
      slidesIn.forEach(function (slide) {
        return slide.classList.add("visible");
      });
    }
  };
  var initServices = function initServices() {
    var services = document.querySelector("#services");
    var isVisible = isInView(services, 300);
    if (isVisible) {
      var number = services.querySelector(".zoom-appear");
      var slidesIn = services.querySelectorAll(".slideInRight");
      var slidesInLeft = services.querySelectorAll(".slideInLeftServices");
      var zoomDown = services.querySelector(".zoomDown");
      number.classList.add("visible");
      zoomDown.classList.add("visible");
      slidesIn.forEach(function (slide) {
        return slide.classList.add("visible");
      });
      slidesInLeft.forEach(function (slide) {
        return slide.classList.add("visible");
      });
    }
  };
  var initGlobal = function initGlobal() {
    var global = document.querySelector("#global");
    var isVisible = isInView(global, 300);
    if (isVisible) {
      var numbers = global.querySelectorAll(".zoom-appear");
      var slidesInRight = global.querySelectorAll(".slideInRight");
      var slidesInLeft = global.querySelectorAll(".slideInLeft");
      var zoomDown = global.querySelector(".zoomDown");
      var slideTop = global.querySelector(".global__wrap-content");
      slideTop.classList.add("visible");
      zoomDown.classList.add("visible");
      numbers.forEach(function (number) {
        return number.classList.add("visible");
      });
      slidesInRight.forEach(function (slide) {
        return slide.classList.add("visible");
      });
      slidesInLeft.forEach(function (slide) {
        return slide.classList.add("visible");
      });
    }
  };
  var initLocation = function initLocation() {
    var locations = document.querySelector("#locations");
    var isVisible = isInView(locations, 300);
    if (isVisible) {
      var slidesTop = locations.querySelector(".locations__wrap-content_bg");
      var wrapMap = locations.querySelector(".locations__wrap-map");
      var scale = locations.querySelector(".locations__wrap-map-template");
      var slidesInRight = locations.querySelectorAll(".slideInRight");
      var slideInRightTitle = locations.querySelectorAll(".slideInRightTitle");
      var slideInLeftLocation = locations.querySelectorAll(".slideInLeftLocation");
      slidesTop.classList.add("visible");
      scale.classList.add("visible");
      wrapMap.classList.add("visible");
      slidesInRight.forEach(function (slide) {
        return slide.classList.add("visible");
      });
      slideInRightTitle.forEach(function (slide) {
        return slide.classList.add("visible");
      });
      slideInLeftLocation.forEach(function (number) {
        return number.classList.add("visible");
      });
    }
  };
  initFadeUp();
  initAbout();
  initServices();
  initGlobal();
  initLocation();
};
document.addEventListener("DOMContentLoaded", function () {
  initAnimations();
});
document.addEventListener("scroll", function () {
  initAnimations();
});

/***/ }),

/***/ "./src/scss/app.scss":
/*!***************************!*\
  !*** ./src/scss/app.scss ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"/js/script": 0,
/******/ 			"css/app": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkTransoil"] = self["webpackChunkTransoil"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	__webpack_require__.O(undefined, ["css/app"], () => (__webpack_require__("./src/js/script.js")))
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["css/app"], () => (__webpack_require__("./src/scss/app.scss")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;